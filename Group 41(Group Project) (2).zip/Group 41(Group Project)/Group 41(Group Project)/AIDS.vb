﻿
' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Interface IAIDS
    Function aids() As Boolean
End Interface
