﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class Cancer
    Inherits Diseases
    Private _Stages As Integer
    Private _Causes As String

    Public Sub New() 'a constructor
        _Stages = 0
        _Causes = ""
    End Sub
    'property methods
    Public Property Stages As Integer
        Get
            Return _Stages
        End Get
        Set(value As Integer)
            If value < 0 Then
                _Stages = 0
            Else
                If value >= 0 And value <= 3 Then
                    _Stages = value
                Else
                    _Stages = 3
                End If
            End If

        End Set
    End Property
    Public Property Causes As String
        Get
            Return _Causes
        End Get
        Set(value As String)
            _Causes = value
        End Set
    End Property

    Public Function LifeExpectancy() As String 'a function return LifeExpectancy
        If Stages = 1 Then
            Return "chemotherapy"
        Else
            If Stages = 2 Then
                Return "Surgery"
            Else
                If Stages = 3 Then
                    Return "Contact Your Doctor"
                End If
            End If
        End If
    End Function

    Public Overrides Function RateOfInfections() As Double
        Return (NumInfection / Population) * 100
    End Function
    Public Overrides Function Display() As String 'a display funcion
        Dim temp As String = ""
        temp &= MyBase.Display()
        temp &= "stages" & CStr(Stages) & Environment.NewLine
        temp &= "causes :" & (Causes) & Environment.NewLine
        temp &= "Life Expectancy :" & CStr(LifeExpectancy())
        Return temp
    End Function
End Class
