﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off

<Serializable()> Public Class HIV
    Inherits Diseases
    Implements IAIDS
    Private _prevention As String
    Private _chronic As Boolean = True
    Private _cd4count As Integer
    Public Property prevention As String
        Get
            Return _prevention
        End Get
        Set(value As String)
            _prevention = value
        End Set
    End Property


    Public Property chronic As Boolean
        Get
            Return _chronic
        End Get
        Set(value As Boolean)
            _chronic = value
        End Set
    End Property
    Public Property cd4count As Double
        Get
            Return _cd4count

        End Get
        Set(value As Double)
            value = _cd4count
        End Set
    End Property
    Public Function cd4countlevel() As String ' will give de stastus of Cd4
        If cd4count < 500 Then
            Return "Your CD4 Count is low."
        Else
            Return "Your CD4 Count is normal/okay"
        End If
    End Function
    Public Overrides Function RateOfInfections() As Double ' calcul thge rate of Infection
        Return (NumInfection / Population) * 100
    End Function
    Public Function aids() As Boolean Implements IAIDS.aids ' will display if you have aids or false
        If cd4count < 500 Then
            Return True
        Else
            Return False
        End If
    End Function
    Public Overrides Function Display() As String
        Dim temp As String = ""
        temp &= MyBase.Display()
        temp &= "Prevention " & prevention & Environment.NewLine
        temp &= "Chronis(true or false)" & CBool(chronic) & Environment.NewLine
        temp &= "CD4 Levél;" & cd4countlevel() & Environment.NewLine
        temp &= "AIDS" & CBool(aids())
        Return temp
    End Function
End Class
