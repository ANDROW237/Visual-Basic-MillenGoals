﻿Option Strict On
Option Explicit On
Option Infer Off
' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary

Public Class frmMilleniumGoals
    Private disease() As Diseases
    Private numdisease As Integer

    Private BF As BinaryFormatter
    Private FS As FileStream
    Private Filename As String = "Disease.Ifm"
    Enum DiseaseChoice ' enum 
        HIV = 1
        Cancer = 2
        Measle = 3
        TB = 4

    End Enum

    Private Sub btnData_Click(sender As Object, e As EventArgs) Handles btnData.Click
        numdisease += 1
        ReDim Preserve disease(numdisease)
        Dim choice As Integer
        Dim name As String
        Dim npopulation As Double
        Dim ndeaths As Integer
        Dim vax As Boolean
        Dim treat As Boolean
        choice = CInt(InputBox("PLease select the disease:" & Environment.NewLine & "1-HIV" & Environment.NewLine & "2-Cancer" & Environment.NewLine & "3-Measle" & Environment.NewLine & "4-TB"))
        name = InputBox("What is the name of the country?")
        npopulation = CDbl(InputBox("what is the total population of this country?"))
        ndeaths = CInt(InputBox("Enter the number of deaths"))
        Dim ninfections As Integer = CInt(InputBox("Enter the number of infections caused by this disease."))
        vax = CBool(InputBox("Is there a vaccine available for this disease in this country? State (True or False)"))
        treat = CBool(InputBox("Is there treatment available for this disease in this country? State (True or False)"))

        Select Case choice
            Case DiseaseChoice.HIV
                Dim objHIV As HIV = New HIV() ' Instantiating
                objHIV.NameCountry = name
                objHIV.Population = npopulation
                objHIV.NumInfection = ninfections
                objHIV.NumDeath = ndeaths
                objHIV.Vaccine = vax
                objHIV.Treatment = treat
                objHIV.prevention = InputBox("please enter the pereventions methods.")
                objHIV.chronic = CBool(InputBox("Is it chronic, State (True or False)."))
                objHIV.cd4count = CDbl(InputBox("please enter the minimum cd4 count."))
                'upcasting
                disease(numdisease) = objHIV

            Case DiseaseChoice.Cancer
                Dim objCancer As Cancer = New Cancer() 'instantiating
                objCancer.NameCountry = name
                objCancer.Population = npopulation
                objCancer.NumInfection = ninfections
                objCancer.NumDeath = ndeaths
                objCancer.Vaccine = vax
                objCancer.Treatment = treat
                objCancer.Causes = InputBox("please enter the causes of cancer.")
                objCancer.Stages = CInt(InputBox("please enter the stage of cancer(1-3)"))
                'upcasting
                disease(numdisease) = objCancer
            Case DiseaseChoice.Measle
                Dim objmeasles As Measles = New Measles() 'instantiating
                objmeasles.NameCountry = name
                objmeasles.Population = npopulation
                objmeasles.NumInfection = ninfections
                objmeasles.Vaccine = vax
                objmeasles.Treatment = treat
                objmeasles.SkinType = CInt(InputBox("enter the number of screen type"))
                'upcasting
                disease(numdisease) = objmeasles

            Case DiseaseChoice.TB
                Dim num As Integer

                num = CInt(InputBox("how many symptoms does TB have?"))
                Dim objTB As TB = New TB(num) 'instatiating
                objTB.NameCountry = name
                objTB.Population = npopulation
                objTB.NumInfection = ninfections
                objTB.NumDeath = ndeaths
                objTB.Vaccine = vax
                objTB.Treatment = treat
                objTB.Numsymptoms = num
                For s As Integer = 1 To objTB.Numsymptoms
                    objTB.Symptoms(s) = InputBox("Name symptom " & CStr(s))
                Next s
                objTB.TBtype = CInt(InputBox("1- Active TB disease , 2- Milliary TB , 3- Latebt TB disease ", "Enter TB type(1-3)"))
                objTB.antibioticstype = CInt(InputBox("1- Amoxilin , 2- Doxycycline, 3- Celphaxin ", "Enter antibiotic type to use for the TB type(1-3)"))
                objTB.Treatmentfees = New TreatmentFee
                objTB.Treatmentfees.Treatmentduration = CInt(InputBox("How many months does the treatment duration lasts?"))
                objTB.Treatmentfees.Treatmentprice = CDbl(InputBox("How much does the treatment cost per month?"))
                'upcasting
                disease(numdisease) = objTB
        End Select









    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        txtDisplay.Text = ""
        For d As Integer = 1 To numdisease
            'polymorphism 
            txtDisplay.Text &= disease(d).Display & Environment.NewLine
        Next d
    End Sub
    ' will write the file 
    Private Sub btnWriteFile_Click(sender As Object, e As EventArgs) Handles btnWriteFile.Click
        FS = New FileStream(Filename, FileMode.Create, FileAccess.Write) 'intiate
        BF = New BinaryFormatter() 'intiate 
        For d As Integer = 1 To numdisease
            BF.Serialize(FS, disease(d))
        Next
        FS.Close()
        FS = Nothing
        BF = Nothing
        MessageBox.Show("All diseases are saved")

    End Sub
    ' will read feom the file
    Private Sub btnReadFile_Click(sender As Object, e As EventArgs) Handles btnReadFile.Click
        FS = New FileStream(Filename, FileMode.Open, FileAccess.Read)
        BF = New BinaryFormatter
        While FS.Position < FS.Length
            Dim d As Diseases
            d = DirectCast(BF.Deserialize(FS), Diseases)
            txtDisplay.Text &= d.Display() & Environment.NewLine

        End While
        FS.Close()
    End Sub
End Class
