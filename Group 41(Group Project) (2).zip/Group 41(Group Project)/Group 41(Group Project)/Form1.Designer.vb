﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMilleniumGoals
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.btnData = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnWriteFile = New System.Windows.Forms.Button()
        Me.btnReadFile = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(201, 12)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(448, 340)
        Me.txtDisplay.TabIndex = 0
        '
        'btnData
        '
        Me.btnData.Location = New System.Drawing.Point(12, 12)
        Me.btnData.Name = "btnData"
        Me.btnData.Size = New System.Drawing.Size(169, 55)
        Me.btnData.TabIndex = 1
        Me.btnData.Text = "Data"
        Me.btnData.UseVisualStyleBackColor = True
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(12, 82)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(169, 55)
        Me.btnDisplay.TabIndex = 1
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnWriteFile
        '
        Me.btnWriteFile.Location = New System.Drawing.Point(12, 152)
        Me.btnWriteFile.Name = "btnWriteFile"
        Me.btnWriteFile.Size = New System.Drawing.Size(169, 55)
        Me.btnWriteFile.TabIndex = 1
        Me.btnWriteFile.Text = "Write"
        Me.btnWriteFile.UseVisualStyleBackColor = True
        '
        'btnReadFile
        '
        Me.btnReadFile.Location = New System.Drawing.Point(12, 224)
        Me.btnReadFile.Name = "btnReadFile"
        Me.btnReadFile.Size = New System.Drawing.Size(169, 55)
        Me.btnReadFile.TabIndex = 1
        Me.btnReadFile.Text = "Read "
        Me.btnReadFile.UseVisualStyleBackColor = True
        '
        'frmMilleniumGoals
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(661, 422)
        Me.Controls.Add(Me.btnReadFile)
        Me.Controls.Add(Me.btnWriteFile)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.btnData)
        Me.Controls.Add(Me.txtDisplay)
        Me.Name = "frmMilleniumGoals"
        Me.Text = "Millenium Goals"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents btnData As Button
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnWriteFile As Button
    Friend WithEvents btnReadFile As Button
End Class
