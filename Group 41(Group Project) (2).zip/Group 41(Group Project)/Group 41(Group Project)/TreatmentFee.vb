﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class TreatmentFee
    Private _Treatmentduration As Integer
    Private _Treatmentprice As Double

    'default constructor
    Public Sub New()
        _Treatmentduration = 0
        _Treatmentprice = 0
    End Sub
    'the duration of the treatment
    Public Property Treatmentduration As Integer
        Get
            Return _Treatmentduration
        End Get
        Set(value As Integer)
            _Treatmentduration = value

        End Set
    End Property

    Public Property Treatmentprice As Double
        Get
            Return _Treatmentprice
        End Get
        Set(value As Double)
            _Treatmentprice = value
        End Set
    End Property

    'medical fee function
    Public Function CalcMedicalfee() As Double
        Return _Treatmentprice * _Treatmentduration
    End Function
End Class
