﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class TB
    Inherits Diseases
    Private _Symptoms() As String             'the symptom array
    Private _TBtype As Integer                 'the type of TB type
    Private _antibioticstype As Integer
    Private _Treatmentfees As TreatmentFee
    Private _Numsymptoms As Integer
    'the constructor
    Public Sub New(num As Integer)
        _Numsymptoms = num
        ReDim _Symptoms(num)
    End Sub

    Public Property Numsymptoms As Integer
        Get
            Return _Numsymptoms
        End Get
        Set(value As Integer)
            _Numsymptoms = value
        End Set
    End Property



    'composited attribute
    Public Property Treatmentfees As TreatmentFee
        Get
            Return _Treatmentfees
        End Get
        Set(value As TreatmentFee)
            _Treatmentfees = value
        End Set
    End Property



    Public Property Symptoms(index As Integer) As String
        Get
            Return _Symptoms(index)
        End Get
        Set(value As String)
            _Symptoms(index) = value
        End Set
    End Property

    Public Property TBtype As Integer
        Get
            Return _TBtype
        End Get
        Set(value As Integer)
            _TBtype = value
        End Set
    End Property

    'the type of antibiotic required 
    Public Property antibioticstype As Integer
        Get
            Return _antibioticstype
        End Get
        Set(value As Integer)
            _antibioticstype = value
        End Set
    End Property

    'prescription function
    Public Function Prescription() As String
        Dim sum As Integer
        Dim output As String
        sum = _TBtype * _antibioticstype

        If sum <= 4 Then
            output = "Visit the clinic once a month"
        Else
            output = "Visit the clinic twice a month"
        End If

        Return output
    End Function
    'overidded function
    Public Overrides Function RateOfInfections() As Double

        Return Population / NumInfection


    End Function

    'overidded function
    Public Overrides Function display() As String


        Dim temp As String = ""
        temp &= MyBase.Display()
        For s As Integer = 1 To _Numsymptoms
            temp &= "Symptom of TB : " & _Symptoms(s) & Environment.NewLine
        Next s
        temp &= "Monthly clinic visitations :" & Prescription() & Environment.NewLine
        temp &= "Medical bill : R" & CStr(_Treatmentfees.CalcMedicalfee) & Environment.NewLine
        Return temp

    End Function
End Class
