﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public MustInherit Class Diseases
    Private _NumDeath As Integer
    Private _NameCountry As String
    Private _Vaccine As Boolean
    Private _Treatment As Boolean
    Private _Population As Double
    Private _NumInfection As Integer
    Public Property NumDeath As Integer
        Get
            Return _NumDeath
        End Get
        Set(value As Integer)
            _NumDeath = value
        End Set
    End Property
    Public Property NameCountry As String
        Get
            Return _NameCountry
        End Get
        Set(value As String)
            _NameCountry = value
        End Set
    End Property
    Public Property Vaccine As Boolean
        Get
            Return _Vaccine
        End Get
        Set(value As Boolean)
            _Vaccine = value
        End Set
    End Property
    Public Property Treatment As Boolean
        Get
            Return _Treatment
        End Get
        Set(value As Boolean)
            _Treatment = value
        End Set
    End Property
    Public Property Population As Double
        Get
            Return _Population
        End Get
        Set(value As Double)
            _Population = value
        End Set
    End Property
    Public Property NumInfection As Integer
        Get
            Return _NumInfection
        End Get
        Set(value As Integer)
            _NumInfection = value
        End Set
    End Property
    Private Shared Function Validation(value As Double) As Double  ' will stop the user to enter a negative value
        If value < 0 Then
            Return 0
        Else
            Return value
        End If
    End Function
    Public MustOverride Function RateOfInfections() As Double 'will Give the rate of infections of the country
    Public Function RateOfDeath() As Double 'will calculate the rate of Death of the country 
        Return (_NumDeath / _Population) * 100
    End Function
    Public Overridable Function Display() As String ' will Display all function
        Dim temp As String = ""
        temp &= "Name Of the Country:" & _NameCountry & Environment.NewLine
        temp &= "Population:" & CStr(_Population) & Environment.NewLine
        temp &= "Number of Infection:" & CStr(_NumInfection) & Environment.NewLine
        temp &= "Number of Deaths :" & CStr(_NumDeath) & Environment.NewLine
        temp &= "Vaccine Or Not (True or False):" & CStr(_Vaccine) & Environment.NewLine
        temp &= "Treatment Or Not (True or False):" & CStr(_Treatment) & Environment.NewLine
        temp &= "Rate Of Infection:" & CStr(RateOfInfections()) & Environment.NewLine
        temp &= "Rate Of Death" & CStr(RateOfDeath()) & Environment.NewLine
        Return temp
    End Function
End Class
