﻿' *****************************************************************
' Team Number: 41
' Team Member 1 Details: POUNGOUE A.L (220033221)
' Team Member 2 Details: Masilela L (220017710)
' Team Member 3 Details: MDLULI, MM (220065507)
' Team Member 4 Details: VILI T (221033701)
' Practical: Diseases
' Class name: Millennium Goals
' *****************************************************************
Option Strict On
Option Explicit On
Option Infer Off
<Serializable()> Public Class Measles
    Inherits Diseases
    Private _Skintype As Integer
    Private _TreatmentDuration As Integer
    Public Sub New() 'a constructor
        SkinType = 0
        TreatmentDuration = 0
    End Sub
    'property methods
    Public Property SkinType As Integer
        Get
            Return _Skintype
        End Get
        Set(value As Integer)
            _Skintype = value
        End Set
    End Property
    Public Property TreatmentDuration As Integer
        Get
            Return _TreatmentDuration
        End Get
        Set(value As Integer)
            _TreatmentDuration = value
        End Set
    End Property
    Public Function SkinRecoveryDuration() As Integer 'a function calculating skinrecovery
        Dim value As Integer
        value = SkinType * TreatmentDuration
        Return value
    End Function

    Public Overrides Function RateOfInfections() As Double
        Return (NumInfection / Population) * 100
    End Function
    Public Overrides Function Display() As String 'a display 
        Dim temp As String = ""
        temp &= MyBase.Display()
        temp &= "skintype " & CStr(SkinType) & Environment.NewLine
        temp &= "TreatmentDuration " & CStr(TreatmentDuration) & " Months" & Environment.NewLine
        temp &= "skinRecoveryDuration " & CStr(SkinRecoveryDuration()) & " Months" & Environment.NewLine
        Return temp
    End Function
End Class
